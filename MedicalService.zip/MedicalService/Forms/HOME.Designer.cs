﻿
namespace MedicalService.Forms
{
    partial class HOME
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnFview = new System.Windows.Forms.Button();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnAview = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnTview = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnProviderHomeMedicineView = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.HomeTextBox = new System.Windows.Forms.TextBox();
            this.Home2panel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.PvdHomeSearchtxt = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.Home2panel.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.MistyRose;
            this.panel8.Controls.Add(this.btnFview);
            this.panel8.Controls.Add(this.pictureBox8);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Location = new System.Drawing.Point(67, 349);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(666, 77);
            this.panel8.TabIndex = 7;
            // 
            // btnFview
            // 
            this.btnFview.BackColor = System.Drawing.Color.MistyRose;
            this.btnFview.FlatAppearance.BorderSize = 0;
            this.btnFview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFview.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnFview.ForeColor = System.Drawing.Color.Maroon;
            this.btnFview.Location = new System.Drawing.Point(555, 26);
            this.btnFview.Name = "btnFview";
            this.btnFview.Size = new System.Drawing.Size(94, 29);
            this.btnFview.TabIndex = 2;
            this.btnFview.Text = "View";
            this.btnFview.UseVisualStyleBackColor = false;
            this.btnFview.Click += new System.EventHandler(this.View4_click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::MedicalService.Properties.Resources.Picture2;
            this.pictureBox8.Location = new System.Drawing.Point(3, 12);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(75, 62);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(102, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 32);
            this.label6.TabIndex = 0;
            this.label6.Text = "First Aid";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.MistyRose;
            this.panel7.Controls.Add(this.btnAview);
            this.panel7.Controls.Add(this.pictureBox7);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(67, 255);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(666, 77);
            this.panel7.TabIndex = 8;
            // 
            // btnAview
            // 
            this.btnAview.BackColor = System.Drawing.Color.MistyRose;
            this.btnAview.FlatAppearance.BorderSize = 0;
            this.btnAview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAview.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAview.ForeColor = System.Drawing.Color.Maroon;
            this.btnAview.Location = new System.Drawing.Point(555, 25);
            this.btnAview.Name = "btnAview";
            this.btnAview.Size = new System.Drawing.Size(94, 29);
            this.btnAview.TabIndex = 2;
            this.btnAview.Text = "View";
            this.btnAview.UseVisualStyleBackColor = false;
            this.btnAview.Click += new System.EventHandler(this.View3_click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::MedicalService.Properties.Resources.Picture10;
            this.pictureBox7.Location = new System.Drawing.Point(3, 12);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(75, 62);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 1;
            this.pictureBox7.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.Maroon;
            this.label7.Location = new System.Drawing.Point(102, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 32);
            this.label7.TabIndex = 0;
            this.label7.Text = "Ambulance";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.MistyRose;
            this.panel6.Controls.Add(this.btnTview);
            this.panel6.Controls.Add(this.pictureBox6);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Location = new System.Drawing.Point(67, 159);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(666, 77);
            this.panel6.TabIndex = 9;
            // 
            // btnTview
            // 
            this.btnTview.BackColor = System.Drawing.Color.MistyRose;
            this.btnTview.FlatAppearance.BorderSize = 0;
            this.btnTview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTview.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTview.ForeColor = System.Drawing.Color.Maroon;
            this.btnTview.Location = new System.Drawing.Point(555, 27);
            this.btnTview.Name = "btnTview";
            this.btnTview.Size = new System.Drawing.Size(94, 29);
            this.btnTview.TabIndex = 2;
            this.btnTview.Text = "View";
            this.btnTview.UseVisualStyleBackColor = false;
            this.btnTview.Click += new System.EventHandler(this.View2_click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::MedicalService.Properties.Resources.Picture12;
            this.pictureBox6.Location = new System.Drawing.Point(3, 12);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(75, 62);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 1;
            this.pictureBox6.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(102, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 32);
            this.label5.TabIndex = 0;
            this.label5.Text = "Tools";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MistyRose;
            this.panel4.Controls.Add(this.panel1);
            this.panel4.Controls.Add(this.btnProviderHomeMedicineView);
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(67, 63);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(666, 77);
            this.panel4.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Maroon;
            this.panel1.Location = new System.Drawing.Point(380, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(169, 105);
            this.panel1.TabIndex = 3;
            // 
            // btnProviderHomeMedicineView
            // 
            this.btnProviderHomeMedicineView.BackColor = System.Drawing.Color.MistyRose;
            this.btnProviderHomeMedicineView.FlatAppearance.BorderSize = 0;
            this.btnProviderHomeMedicineView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProviderHomeMedicineView.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnProviderHomeMedicineView.ForeColor = System.Drawing.Color.Maroon;
            this.btnProviderHomeMedicineView.Location = new System.Drawing.Point(555, 26);
            this.btnProviderHomeMedicineView.Name = "btnProviderHomeMedicineView";
            this.btnProviderHomeMedicineView.Size = new System.Drawing.Size(94, 29);
            this.btnProviderHomeMedicineView.TabIndex = 2;
            this.btnProviderHomeMedicineView.Text = "View";
            this.btnProviderHomeMedicineView.UseVisualStyleBackColor = false;
            this.btnProviderHomeMedicineView.Click += new System.EventHandler(this.PvdHomeMedicineView_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::MedicalService.Properties.Resources.Picture11;
            this.pictureBox2.Location = new System.Drawing.Point(3, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(75, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(102, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 32);
            this.label4.TabIndex = 0;
            this.label4.Text = "Medicines";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.Salmon;
            this.label3.Location = new System.Drawing.Point(67, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "Available Services";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Brown;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSearch.ForeColor = System.Drawing.Color.LightCoral;
            this.btnSearch.Location = new System.Drawing.Point(654, 16);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 29);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            // 
            // HomeTextBox
            // 
            this.HomeTextBox.BackColor = System.Drawing.Color.MistyRose;
            this.HomeTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.HomeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.HomeTextBox.ForeColor = System.Drawing.Color.Firebrick;
            this.HomeTextBox.Location = new System.Drawing.Point(356, 15);
            this.HomeTextBox.Multiline = true;
            this.HomeTextBox.Name = "HomeTextBox";
            this.HomeTextBox.Size = new System.Drawing.Size(292, 31);
            this.HomeTextBox.TabIndex = 11;
            this.HomeTextBox.Text = "Search in your services";
            this.HomeTextBox.Click += new System.EventHandler(this.HomeSearchtext_click);
            // 
            // Home2panel
            // 
            this.Home2panel.Controls.Add(this.button1);
            this.Home2panel.Controls.Add(this.PvdHomeSearchtxt);
            this.Home2panel.Controls.Add(this.panel3);
            this.Home2panel.Controls.Add(this.panel5);
            this.Home2panel.Controls.Add(this.panel9);
            this.Home2panel.Controls.Add(this.panel10);
            this.Home2panel.Controls.Add(this.label10);
            this.Home2panel.ForeColor = System.Drawing.Color.Maroon;
            this.Home2panel.Location = new System.Drawing.Point(3, 0);
            this.Home2panel.Name = "Home2panel";
            this.Home2panel.Size = new System.Drawing.Size(807, 452);
            this.Home2panel.TabIndex = 13;
            this.Home2panel.Paint += new System.Windows.Forms.PaintEventHandler(this.Home2panel_Paint);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Brown;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.LightCoral;
            this.button1.Location = new System.Drawing.Point(657, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 29);
            this.button1.TabIndex = 19;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // PvdHomeSearchtxt
            // 
            this.PvdHomeSearchtxt.BackColor = System.Drawing.Color.MistyRose;
            this.PvdHomeSearchtxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PvdHomeSearchtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.PvdHomeSearchtxt.ForeColor = System.Drawing.Color.Firebrick;
            this.PvdHomeSearchtxt.Location = new System.Drawing.Point(359, 20);
            this.PvdHomeSearchtxt.Multiline = true;
            this.PvdHomeSearchtxt.Name = "PvdHomeSearchtxt";
            this.PvdHomeSearchtxt.Size = new System.Drawing.Size(292, 31);
            this.PvdHomeSearchtxt.TabIndex = 18;
            this.PvdHomeSearchtxt.Text = "Search in your services";
            this.PvdHomeSearchtxt.Click += new System.EventHandler(this.PvdHomeSearch_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MistyRose;
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(70, 354);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(666, 77);
            this.panel3.TabIndex = 14;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MistyRose;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.ForeColor = System.Drawing.Color.Maroon;
            this.button2.Location = new System.Drawing.Point(555, 26);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 29);
            this.button2.TabIndex = 2;
            this.button2.Text = "View";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.PvdAidView_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MedicalService.Properties.Resources.Picture2;
            this.pictureBox1.Location = new System.Drawing.Point(3, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(75, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(102, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Aid";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MistyRose;
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.pictureBox3);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Location = new System.Drawing.Point(70, 260);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(666, 77);
            this.panel5.TabIndex = 15;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.MistyRose;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button3.ForeColor = System.Drawing.Color.Maroon;
            this.button3.Location = new System.Drawing.Point(555, 25);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 29);
            this.button3.TabIndex = 2;
            this.button3.Text = "View";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.PvdAmbView_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::MedicalService.Properties.Resources.Picture10;
            this.pictureBox3.Location = new System.Drawing.Point(3, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(75, 62);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(102, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ambulance";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.MistyRose;
            this.panel9.Controls.Add(this.button4);
            this.panel9.Controls.Add(this.pictureBox4);
            this.panel9.Controls.Add(this.label8);
            this.panel9.Location = new System.Drawing.Point(70, 164);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(666, 77);
            this.panel9.TabIndex = 16;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.MistyRose;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button4.ForeColor = System.Drawing.Color.Maroon;
            this.button4.Location = new System.Drawing.Point(549, 39);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(94, 29);
            this.button4.TabIndex = 2;
            this.button4.Text = "View";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.pvdToolsView_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::MedicalService.Properties.Resources.Picture12;
            this.pictureBox4.Location = new System.Drawing.Point(3, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(75, 62);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.Maroon;
            this.label8.Location = new System.Drawing.Point(102, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 32);
            this.label8.TabIndex = 0;
            this.label8.Text = "Tools";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.MistyRose;
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.button5);
            this.panel10.Controls.Add(this.pictureBox5);
            this.panel10.Controls.Add(this.label9);
            this.panel10.Location = new System.Drawing.Point(70, 68);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(666, 77);
            this.panel10.TabIndex = 17;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Maroon;
            this.panel11.Location = new System.Drawing.Point(380, 81);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(169, 105);
            this.panel11.TabIndex = 3;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.MistyRose;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button5.ForeColor = System.Drawing.Color.Maroon;
            this.button5.Location = new System.Drawing.Point(555, 26);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(94, 29);
            this.button5.TabIndex = 2;
            this.button5.Text = "View";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.pvdMdcView_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::MedicalService.Properties.Resources.Picture11;
            this.pictureBox5.Location = new System.Drawing.Point(3, 9);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(75, 62);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.Maroon;
            this.label9.Location = new System.Drawing.Point(102, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(152, 32);
            this.label9.TabIndex = 0;
            this.label9.Text = "Medicines";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.ForeColor = System.Drawing.Color.Salmon;
            this.label10.Location = new System.Drawing.Point(70, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(175, 22);
            this.label10.TabIndex = 13;
            this.label10.Text = "Available Services";
            // 
            // HOME
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Home2panel);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.HomeTextBox);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label3);
            this.Name = "HOME";
            this.Text = "HOME";
            this.Load += new System.EventHandler(this.HOME_Load_1);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.Home2panel.ResumeLayout(false);
            this.Home2panel.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnFview;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnAview;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btnTview;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnProviderHomeMedicineView;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox HomeTextBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel Home2panel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox PvdHomeSearchtxt;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}